# ActiveCourse Studio

Plan → Teach → Capture → Reflect → Adapt.

A week-by-week course planner built for **Caribbean higher education and face-to-face teaching**. It imports your course outline, checks each session against constructive alignment and active-learning evidence, drafts sessions with Claude, keeps a personal layer that AI never overwrites, and exports weekly plans and a quality-assurance dossier as Word, PDF, Markdown or CSV.

Everything except the AI features works with no internet at all.

---

## What it does

**Imports your outline.** Drop in a .docx, .pdf, .txt, .md or .csv, or paste the text. Weeks, objectives, readings and assessments are pulled out. With no API key it falls back to pattern reading, which handles most outlines on its own.

**Checks the teaching, not just the paperwork.** Every week gets an instant score computed on your own machine — no AI, no network, same answer every time:

- **Constructive alignment.** Every objective is matched against what actually happens in the room. Orphaned objectives are named.
- **Bloom's level.** The first verb of each objective is read against the revised taxonomy. Weeks that never leave recall and understanding are flagged.
- **Time on task.** Students working should clear 45% of contact time; transmission should stay under a third. Any unbroken input block over 20 minutes is flagged on its own.
- **Evidence of learning.** Each move names what it produces. Fewer than three collection points in a session is flagged.
- **The real room.** Class size, room type and how reliable the technology is are all taken into account. Small groups in fixed tiered seating are flagged unless you have said how groups form. A session leaning on a projector you cannot count on is flagged unless the fallback is written down.
- **Inclusion and locality.** Adjustments for the group in front of you, and at least one local or regional example.

**The move library.** Forty named face-to-face techniques — think-pair-share, peer instruction, jigsaw, numbered heads together, board relay, structured academic controversy, local case swap, and the rest. Each one lists the evidence it produces, the largest class it survives, whether it needs any technology, and whether it works in fixed seats. Filters default to what your room can actually take. One click inserts it into the week.

**Course view.** The shape of the whole term: where the listening piles up, where assessments collide, which levels of thinking the course never asks for, reading load, and reflection captured.

**Your layer.** Hook, local and lived examples, adjustments, materials. Nothing here comes from the outline and nothing here is overwritten when you re-import or redraft.

**AI drafting and coaching.** Drafts a full session from the topic, objectives, readings, your room, your class size and your personal layer. Every draft is constrained: minutes must add up, students must be working for at least half the session, no input block over 15 minutes, every objective practised, no invented citations. Ground examples in the Caribbean with one checkbox; assume board-and-paper only with another. Nothing changes until you press Apply, and you choose which parts to take.

**Exports.** Word, printable HTML/PDF, Markdown, a CSV outcome map (week, objective, Bloom level, moves, evidence, assessment), a JSON backup, and a **quality-assurance dossier** that reorganises your plan under the areas Caribbean accreditation and internal review panels ask about — outcomes, curriculum structure, teaching strategies, assessment, student support, resources, monitoring — with the evidence already filled in from your weeks.

> The dossier's headings are generic quality areas common to UCJ, ACTT, BAC, the national councils and institutional self-studies. Check your own body's current handbook for their exact wording and numbering, then move the evidence under it.

---

## Files

- `index.html` — the whole application. No build step, no framework, no dependencies.
- `api/claude.js` — serverless proxy that adds the Anthropic API key server-side.
- `vercel.json` — 60-second function duration, since drafting a week takes time.

## Deploy

1. Push these files to a Git repository, or drop the folder on [vercel.com/new](https://vercel.com/new).
2. In the project: **Settings → Environment Variables → Add**
   - Name: `ANTHROPIC_API_KEY`
   - Value: your key from [console.anthropic.com](https://console.anthropic.com)
   - Environments: Production, Preview, Development
3. **Redeploy.** Environment variables only reach a build that runs after they are set.

Without the key the planner still works completely: outline import falls back to pattern reading, and the quality check, the move library, the course view and every export need no network whatsoever. Only AI drafting and the coach need the key.

### Check it worked

Open the site, create a course, type a topic into week one, and press **Draft this week with AI**. If it reports that the AI features are not switched on, the environment variable is missing or the deployment predates it.

## Running it off your desktop

Open `index.html` directly in a browser and everything works except the AI, because there is no proxy. If you want AI locally, paste an API key into Settings; it stays in that browser and is never sent anywhere except Anthropic.

## Where the data lives

Course data is saved in the browser of whoever is using it. Nothing is stored on the server, and the proxy keeps no record of your course content. Use **Export → Back up every course** before switching machines or clearing browser data. If you later want courses to follow you across devices, that needs a database behind the same `api/` folder.

## Cost

Each AI draft is one short request. Drafting a full thirteen-week course is thirteen requests. Usage is billed to the Anthropic account behind the key, so do not put this on a public URL with your own key unless you intend to pay for other people's drafting.

## Keyboard

- `Alt` + `←` / `→` — previous and next week
- `Esc` — close any dialogue
