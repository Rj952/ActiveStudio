/**
 * Serverless proxy for the Anthropic Messages API.
 *
 * The browser never sees the key. It posts the same body it would send to
 * Anthropic directly; this function adds the key from the environment and
 * passes the response straight back.
 *
 * Set ANTHROPIC_API_KEY in Vercel: Settings -> Environment Variables.
 */

const ALLOWED_MODELS = [
  "claude-sonnet-4-6",
  "claude-sonnet-4-5",
  "claude-opus-4-6",
  "claude-haiku-4-5"
];
const DEFAULT_MODEL = "claude-sonnet-4-6";
const MAX_BODY = 200000;      // characters of JSON we are willing to forward
const MAX_TOKENS_CAP = 4000;
const UPSTREAM_TIMEOUT = 55000;

function send(res, status, obj) {
  res.statusCode = status;
  res.setHeader("Content-Type", "application/json; charset=utf-8");
  res.setHeader("Cache-Control", "no-store");
  res.end(JSON.stringify(obj));
}

async function readBody(req) {
  if (req.body && typeof req.body === "object") return req.body;
  if (typeof req.body === "string" && req.body) return JSON.parse(req.body);
  const chunks = [];
  let size = 0;
  for await (const chunk of req) {
    size += chunk.length;
    if (size > MAX_BODY) throw new Error("That outline is too large to send in one request.");
    chunks.push(chunk);
  }
  const raw = Buffer.concat(chunks).toString("utf8");
  return raw ? JSON.parse(raw) : {};
}

module.exports = async function handler(req, res) {
  if (req.method === "OPTIONS") {
    res.setHeader("Allow", "POST, OPTIONS");
    res.statusCode = 204;
    return res.end();
  }
  if (req.method !== "POST") {
    res.setHeader("Allow", "POST, OPTIONS");
    return send(res, 405, { error: "Use POST." });
  }

  const key = process.env.ANTHROPIC_API_KEY;
  if (!key) {
    return send(res, 503, {
      error:
        "The AI features are not switched on for this deployment. Add ANTHROPIC_API_KEY in Vercel under Settings, Environment Variables, then redeploy."
    });
  }

  let body;
  try {
    body = await readBody(req);
  } catch (err) {
    return send(res, 400, { error: err.message || "Could not read the request." });
  }

  if (!Array.isArray(body.messages) || !body.messages.length) {
    return send(res, 400, { error: "No messages were sent." });
  }

  const payload = {
    model: ALLOWED_MODELS.includes(body.model) ? body.model : DEFAULT_MODEL,
    max_tokens: Math.min(MAX_TOKENS_CAP, Math.max(1, parseInt(body.max_tokens, 10) || 1000)),
    messages: body.messages
  };
  if (typeof body.system === "string" && body.system.trim()) payload.system = body.system;

  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), UPSTREAM_TIMEOUT);

  try {
    const upstream = await fetch("https://api.anthropic.com/v1/messages", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "x-api-key": key,
        "anthropic-version": "2023-06-01"
      },
      body: JSON.stringify(payload),
      signal: controller.signal
    });

    const text = await upstream.text();

    if (!upstream.ok) {
      let detail = "";
      try {
        const j = JSON.parse(text);
        detail = (j.error && j.error.message) || "";
      } catch (e) {
        /* upstream returned something that is not JSON */
      }
      const friendly =
        upstream.status === 401
          ? "The API key on this deployment was rejected. Check ANTHROPIC_API_KEY in Vercel."
          : upstream.status === 429
          ? "Anthropic is rate limiting this key. Wait a moment and try again."
          : upstream.status >= 500
          ? "Anthropic is having trouble right now. Try again shortly."
          : detail || "Claude returned an error.";
      return send(res, upstream.status, { error: friendly });
    }

    res.statusCode = 200;
    res.setHeader("Content-Type", "application/json; charset=utf-8");
    res.setHeader("Cache-Control", "no-store");
    return res.end(text);
  } catch (err) {
    const aborted = err && (err.name === "AbortError" || err.code === "ABORT_ERR");
    return send(res, aborted ? 504 : 502, {
      error: aborted
        ? "That took too long. Try drafting a single week rather than the whole course at once."
        : "Could not reach Claude from the server."
    });
  } finally {
    clearTimeout(timer);
  }
};
